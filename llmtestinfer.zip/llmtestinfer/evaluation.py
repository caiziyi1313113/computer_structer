from transformers import AutoModel, AutoTokenizer
import torch
import json
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
from judgement import OllamaChat


class Evaluator:
    def __init__(self, model_name="sentence-transformers/all-MiniLM-L6-v2"):
        """
        初始化文本相似度计算的模型
        :param model_name: 默认值是"sentence-transformers/all-MiniLM-L6-v2"
        """
        # 检查 GPU 是否可用
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        # 加载 tokenizer 和 model
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModel.from_pretrained(model_name).to(self.device)  # 将模型加载到 GPU 或 CPU 上

    def get_embedding(self, text):
        """
        获取文本的嵌入向量
        :param text: 需要计算的文本
        :return: 嵌入向量
        """
        inputs = self.tokenizer(text, return_tensors="pt", padding=True, truncation=True).to(
            self.device)  # 将输入数据转移到同样的设备（GPU 或 CPU）

        with torch.no_grad():
            # 获取模型输出，并确保模型计算是在 GPU 或 CPU 上进行
            outputs = self.model(**inputs)
            # 获取每个句子的嵌入向量并转移到 CPU，再转换为 numpy 数组
            return outputs.last_hidden_state.mean(dim=1).cpu().numpy()

    def compute_similarity(self, text1, text2):
        """
        计算两个文本的相似度
        :param text1: 第一个文本
        :param text2: 第二个文本
        :return: 余弦相似度
        """
        vec1 = self.get_embedding(text1)
        vec2 = self.get_embedding(text2)

        # cosine_similarity要求输入为二维
        return cosine_similarity(vec1, vec2)[0][0]

    def evaluate(self, final_response, correct_option, id, conversation_length):
        """
        评估最终回答的文本相似度和 token 数量
        :param final_response: 生成的最终回答
        :param correct_option: 正确答案选项
        :param id: 数据编号
        :param conversation_length: 对话轮数
        :return: 评估结果字典
        """
        similarity = float(self.compute_similarity(final_response, correct_option))
        tokens = len(final_response.split())

        # 调用 AI 判官，以 gemma3:12b 充当 judgement
        AI_judgement = OllamaChat(model_name='gemma3:12b')
        score_byzhipu, reason_byzhipu = AI_judgement.chat(final_response, correct_option)

        result = {
            "id": id,
            "conversation_length": conversation_length,
            "similarity": similarity,
            "tokens": tokens,
            "score_byzhipu": score_byzhipu,
            "reason_byzhipu": reason_byzhipu
        }

        # 先读取现有的 JSON 文件内容
        try:
            with open("evaluation_results_deepseek-chat.json", "r", encoding="utf-8") as f:
                data = json.load(f)
        except FileNotFoundError:
            # 如果文件不存在，则创建一个空的列表
            data = []

        # 将新结果追加到数据列表中
        data.append(result)

        # 将所有数据写入 JSON 文件
        with open("evaluation_results_deepseek-chat.json", "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=4)

        return result
