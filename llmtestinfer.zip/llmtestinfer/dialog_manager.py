import random
from zhipuai import ZhipuAI  # Assuming you have imported ZhipuAI SDK
import time
import re
from openai import OpenAI

# 调用 ZhipuAI 的 AI
#调用阿里云的通义千问ai
class ChatBot:
    def __init__(self, model_name, api_key):
        """
        初始化 LLM 模型
        :param model_name: 预训练模型名称
        :param api_key: ZhipuAI 的 API 密钥
        """
        #self.client=ZhipuAI(api_key)
        self.client = OpenAI(
            api_key=api_key,
            base_url="https://api.deepseek.com/v1"
            #base_url="https://dashscope.aliyuncs.com/compatible-mode/v1"
        )
        self.model_name = model_name

    def chat(self, context):
        """
        让模型基于上下文进行对话
        :param context: 历史对话上下文
        :return: 模型生成的文本
        """
        ai_response = self.client.chat.completions.create(
            model=self.model_name,
            messages=[
                {"role": "system", "content": "System role context here."},
                {"role": "user", "content": context}
            ],
            stream=True  # 流式响应
        )

        response = ""#看是否修改
        for chunk in ai_response:
            if hasattr(chunk, "choices") and chunk.choices:
                delta = chunk.choices[0].delta
                content = getattr(delta, "content", "")
                if content is not None:
                    #print(f"Delta content: {content}")  # 进一步调试
                    response += content  # 安全拼接
            else:
                print("Error: Chunk does not have 'choices' or 'choice' attribute.")

        return response
'''
    def chat(self, context):
        """
        让模型基于上下文进行对话
        :param context: 历史对话上下文
        :return: 模型生成的文本
        """
        # 使用 ZhipuAI 进行流式响应生成
        ai_response = self.client.chat.completions.create(
            model=self.model_name,
            messages=[{"role": "system", "content": "System role context here."},
                      {"role": "user", "content": context}],
            stream=True,  # 流式响应
        )
        #ZhipuAI API 返回的 ChatCompletionChunk 对象并不是一个字典，而是一个类实例。为了正确获取 ChatCompletionChunk 对象中的内容，我们需要访问其属性，而不是尝试直接通过索引访问
        #我们应该访问 ChatCompletionChunk 类的相应属性，而不是直接使用索引。假设该类有 choices 属性，并且你可以通过 .choices 属性获取对话内容。你可以通过查看 ZhipuAI SDK 的文档或者使用 print(chunk) 来查看对象的实际结构。
        # 收集流式响应并返回

        response = ""
        for chunk in ai_response:
            #print(chunk)
            # 如果 ChatCompletionChunk 有 choices 属性，则访问正确的属性
            # chunk格式
            # ChatCompletionChunk(id='202503241512172189bf35c6054d8c', choices=[Choice(delta=ChoiceDelta(content='Your', role='assistant', tool_calls=None, audio=None), finish_reason=None, index=0)], created=1742800337, model='glm-4-flash', usage=None, extra_json=None)
            if hasattr(chunk, 'choices'):
                response += chunk.choices[0].delta.content
            else:
                print("Error: Chunk does not have 'choices'.")
            time.sleep(0.1)  # 控制流速，防止过快发送
        return response
'''




def run_dialogue(data_entry, model_M, model_F):
    """
    运行 M 和 F 之间的多轮对话
    :param data_entry: 单条数据
    :param model_M: 扮演 M 的 LLM
    :param model_F: 扮演 F 的 LLM
    :return: 生成的完整对话和最终回答
    """

    article = data_entry["article"]

    # 按 "m :" 和 "f :" 分割对话
    conversation = re.split(r'(m :|f :)', article)
    # 去掉第一个空字符串
    conversation = [line.strip() for line in conversation if line.strip()]

    full_history = []
    messages = []

    # 按照角色划分对话
    for i in range(0, len(conversation)-1, 2):
        role = conversation[i].strip()  # 获取角色（m 或 f）
        #print(role)
        content = conversation[i + 1].strip()  # 获取对话内容
        #print((content))
        if role == 'm :':
            messages.append({"role": 'm', "content": content})  # 假设 m 是用户
        elif role == 'f :':
            messages.append({"role": 'f', "content": content})  # 假设 f 是助手
        #print(messages)

    # 模拟多轮对话
    for message in messages:
        # 更新对话历史,将当前最新的对话传递给历史窗口中，不然第一次对话为空
        full_history.append(message)
        # 拼接对话历史作为上下文传递给模型
        context = "\n".join([msg["content"] for msg in full_history])
        # 根据当前角色生成回答
        if message["role"] == 'm':
            response = model_M.chat(context)  # 让 M 回复
        else:
            response = model_F.chat(context)  # 让 F 回复

        full_history.append({"role": message["role"], "content": response})


        # 判断最后一个对话是谁说的，来决定谁生成最终的回答
    last_role = messages[-1]["role"]
    if last_role == 'm':
        final_response = model_M.chat("\n".join([msg["content"] for msg in full_history]))  # 最后由 M 给出回答
    else:
        final_response = model_F.chat("\n".join([msg["content"] for msg in full_history]))  # 最后由 F 给出回答
    return full_history, final_response