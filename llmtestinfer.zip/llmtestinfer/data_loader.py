import os
import json


def load_and_save_data(folder_path, output_file="output_data_4.json"):
    data = []

    # 遍历文件夹中的所有文件
    for i in range(42,105):#假设文件名为 train_1.txt 到 train_7088.txt
        file_path = os.path.join(folder_path, f"train_{i}.txt")

        # 如果文件存在，则读取文件
        if os.path.exists(file_path):
            with open(file_path, "r", encoding="utf-8") as f:
                content = f.read()

            try:
                # 解析 content 字段为 JSON 格式
                parsed_content = json.loads(content)

                # 构造新的数据结构
                data_entry = {
                    "id": parsed_content["id"],  # 唯一标识
                    "article": parsed_content["article"],  # 对话内容
                    "options": parsed_content["options"],  # 选项
                    "answers": parsed_content["answers"]  # 正确答案
                }
                data.append(data_entry)

            except json.JSONDecodeError:
                print(f"文件 {file_path} 格式错误，跳过该文件。")

    return data




