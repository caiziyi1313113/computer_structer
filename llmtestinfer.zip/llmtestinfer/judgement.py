'''
import time
from zhipuai import ZhipuAI  # 假设 zhipuai 是该模块的名称


class ZhipuAIChat:
    def __init__(self, api_key, model_name="glm-4-flash"):
        """
        初始化 ZhipuAI Chat 类
        :param api_key: ZhipuAI API 密钥
        :param model_name: 模型名称，默认是 "glm-4"
        """
        self.client = ZhipuAI(api_key=api_key)
        self.model_name = model_name

    def chat(self, final_response, correct_option):
        """
        让模型基于 final_response 和 correct_option 进行判断，返回分数和理由
        :param final_response: 生成的最终回答
        :param correct_option: 正确的答案选项
        :return: 模型的分数和理由
        """
        # 定义用户问题：请模型判断 final_response 是否正确表达 correct_option
        context = f"""
        请问判官，这个 final_response 能否正确表达这个 correct_option 的意思？
        请在回答开头就给出分数（从0到100进行打分），分数后面给出理由。（请用中文回答）

        final_response: "{final_response}"
        correct_option: "{correct_option}"
        """

        # 使用 ZhipuAI 进行流式响应生成
        ai_response = self.client.chat.completions.create(
            model=self.model_name,
            messages=[{"role": "system", "content": "System role context here."},
                      {"role": "user", "content": context}],
            stream=True,  # 流式响应
        )

        # 收集流式响应并返回
        response = ""
        for chunk in ai_response:
            # 判断 chunk 是否包含 choices 属性，并拼接内容
            if hasattr(chunk, 'choices'):
                response += chunk.choices[0].delta.content
            else:
                print("Error: Chunk does not have 'choices'.")
            time.sleep(0.1)  # 控制流速，防止过快发送
        print('judgement给出的答案',response)
        # 分离分数和理由
        score, reason = self.extract_score_and_reason(response)
        return score, reason

    def extract_score_and_reason(self, response):
        """
        从模型的响应中提取分数和理由
        :param response: 模型的完整回答
        :return: 分数和理由
        """
        try:
            # 将响应按换行符分割为多行，首先提取分数
            lines = response.split('\n')
            print(lines)
            # 获取分数
            score = lines[0].strip()  # 假设第一行是分数
            print(score)
            # 获取理由
            reason = '\n'.join(lines[1:]).strip()  # 剩余的部分是理由

            return score, reason

        except ValueError:
            # 如果格式不正确，返回默认的分数和理由
            return 0, "无法提取分数和理由。"
'''

import time
import ollama
import re

class OllamaChat:
    def __init__(self, model_name="mistral"):
        """
        初始化 Ollama Chat 类
        :param model_name: 模型名称，默认是 "mistral"
        """
        self.model_name = model_name

    def chat(self, final_response, correct_option):
        """
        让模型基于 final_response 和 correct_option 进行判断，返回分数和理由
        :param final_response: 生成的最终回答
        :param correct_option: 正确的答案选项
        :return: 模型的分数和理由
        """
        # 定义用户问题：请模型判断 final_response 是否正确表达 correct_option
        context = f"""
        请在回答开头就‘这个 final_response 能否正确表达这个 correct_option 的意思’问题给出分数（从0到100进行打分），分数后面给出理由。
        （请用中文回答,回答格式，先给出分数，再给出理由）

        final_response: "{final_response}"
        correct_option: "{correct_option}"
        """

        # 使用 Ollama 进行对话
        ai_response = ollama.chat(
            model=self.model_name,
            messages=[
                {"role": "system", "content": "System role context here."},
                {"role": "user", "content": context}
            ]
        )

        response = ai_response['message']['content']
        #print(response)
        #print(response)
        # 分离分数和理由
        score, reason = self.extract_score_and_reason(response)
        return score, reason

    def extract_score_and_reason(self, response):
        """
        从模型的响应中提取分数和理由
        :param response: 模型的完整回答
        :return: 分数和理由
        """
        try:
            # 将响应按换行符分割为多行，首先提取分数
            lines = response.split('\n')
            #print(lines)
            # 获取分数
            score = lines[0].strip()  # 假设第一行是分数
            #print(score)
            # 获取理由
            reason = '\n'.join(lines[1:]).strip()  # 剩余的部分是理由

            return score, reason

        except ValueError:
            # 如果格式不正确，返回默认的分数和理由
            return 0, "无法提取分数和理由。"
