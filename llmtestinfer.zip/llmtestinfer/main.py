from data_loader import load_and_save_data
from dialog_manager import ChatBot, run_dialogue
from evaluation import Evaluator
#from native_model import ChatBot,run_dialogue
# 设定待测大模型（可更换成其他 LLM）
#MODEL_NAME = "facebook/opt-1.3b"

import json

'''
# 加载 JSON 文件数据，并从指定 ID 开始读取
def load_and_save_data(json_file, start_id):
    with open(json_file, "r", encoding="utf-8") as file:
        data = json.load(file)  # 读取 JSON 数据

    # 找到起始 ID 的索引
    for i, entry in enumerate(data):
        if entry["id"] == f"train_{start_id}":
            return data[i:]  # 从找到的索引开始返回数据

    return []  # 如果未找到指定 ID，则返回空列表


# 指定 JSON 文件路径和起始 ID
json_file = "output_data_4.json"
start_id = 255#234-238 247
'''


# 读取数据
train_dir = "train"

# 加载数据
data = load_and_save_data(train_dir)

#model_name='glm-4-flash'
#model_name='qwq-plus'
model_name='deepseek-chat'
# 初始化 M 和 F 角色的 LLM#这个大模型初始化应该在每一次对话都初始化吗
model_M = ChatBot(model_name,'sk-205153deab7c4e05b75e8065d64c49ff')
model_F = ChatBot(model_name,'sk-b074d7481c5d4c93a23c55e25c0c756e')

# 初始化评估器
evaluator = Evaluator()

# 遍历数据进行多轮对话和评估
for entry in data:
    print(f"Processing {entry['id']}...")
    # 运行对话，entry是每一个f''{test_{i}}
    history, final_response = run_dialogue(entry, model_M, model_F)
    # 获取正确答案
    correct_answer_index = ord(entry["answers"]) - ord("A")
    correct_option = entry["options"][correct_answer_index]
    # 评估最终回答
    #en(history) // 2 的意思是获取 history 中元素个数的整数除以 2，即将 history 的长度除以 2，并向下取整。
    result = evaluator.evaluate(final_response, correct_option, entry["id"], len(history) // 2)

    print(f"finish{entry['id']}···")
    #print(f"Evaluation for {entry['id']}: {result}")
