import ollama
import re
import time


# 使用 Ollama 本地部署的模型
class ChatBot:
    def __init__(self, model_name):
        """
        初始化本地 LLM 模型
        :param model_name: 预训练模型名称（如 "llama3", "mistral"）
        """
        self.model_name = model_name

    def chat(self, context):
        """
        让模型基于上下文进行对话
        :param context: 历史对话上下文
        :return: 模型生成的文本
        """
        ai_response = ollama.chat(
            model=self.model_name,
            messages=[
                {"role": "system", "content": "System role context here."},
                {"role": "user", "content": context}
            ]
        )

        return ai_response['message']['content']


def run_dialogue(data_entry, model_M, model_F):
    """
    运行 M 和 F 之间的多轮对话
    :param data_entry: 单条数据
    :param model_M: 扮演 M 的 LLM
    :param model_F: 扮演 F 的 LLM
    :return: 生成的完整对话和最终回答
    """
    article = data_entry["article"]

    # 按 "m :" 和 "f :" 分割对话
    conversation = re.split(r'(m :|f :)', article)
    conversation = [line.strip() for line in conversation if line.strip()]

    full_history = []
    messages = []

    # 按照角色划分对话
    for i in range(0, len(conversation) - 1, 2):
        role = conversation[i].strip()
        content = conversation[i + 1].strip()
        if role == 'm :':
            messages.append({"role": 'm', "content": content})
        elif role == 'f :':
            messages.append({"role": 'f', "content": content})

    # 模拟多轮对话
    for message in messages:
        full_history.append(message)
        context = "\n".join([msg["content"] for msg in full_history])

        if message["role"] == 'm':
            response = model_M.chat(context)
        else:
            response = model_F.chat(context)

        full_history.append({"role": message["role"], "content": response})
        time.sleep(0.1)  # 控制流速

    # 最终回答
    last_role = messages[-1]["role"]
    final_response = model_M.chat(
        "\n".join([msg["content"] for msg in full_history])) if last_role == 'm' else model_F.chat(
        "\n".join([msg["content"] for msg in full_history]))

    return full_history, final_response